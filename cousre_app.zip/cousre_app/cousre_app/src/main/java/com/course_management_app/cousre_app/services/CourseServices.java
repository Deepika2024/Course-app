package com.course_management_app.cousre_app.services;

import com.course_management_app.cousre_app.entites.Course;
import org.springframework.stereotype.Service;

import java.util.List;


public interface CourseServices {

    public List<Course> getCourses();

    Course getCourse(long id);

    Course addCourse(Course course);

    Course updateCourse(Course course);

    void deleteCourse(long courseID);
}

