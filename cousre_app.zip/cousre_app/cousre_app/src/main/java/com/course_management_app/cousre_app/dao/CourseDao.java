package com.course_management_app.cousre_app.dao;


import com.course_management_app.cousre_app.entites.Course;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CourseDao extends JpaRepository<Course, Long> {
}

