package com.course_management_app.cousre_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CousreAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CousreAppApplication.class, args);
	}

}
